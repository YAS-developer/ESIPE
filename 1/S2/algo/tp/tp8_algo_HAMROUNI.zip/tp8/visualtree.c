#include "visualtree.h"
#include <stdio.h>
#include <stdlib.h>

/*
 * Open a file and start writing the DOT code for a tree.
 * Returns a pointer to the file.
 */
FILE* write_begin(char *name) {
    FILE *f = fopen(name, "w");
    fprintf(f, "digraph tree {\n");
    fprintf(f, "  splines=false\n");
    fprintf(f, "  node [shape=record,height=.1]\n");
    fprintf(f, "  edge [tailclip=false, arrowtail=dot, dir=both];\n\n");
    return f;
}

/*
 * Write the terminating brace and close the file.
 */
void write_end(FILE *f) {
    fprintf(f, "\n}\n");
    fclose(f);
}

/*
 * Write the DOT code for a single node n to an open file f.
 */
void write_node(FILE *f, node *n) {
    fprintf(f, "  n%p [label=\"<left> | <value> %s | <right>\"];\n", n, n->word);
}

/*
 * Write the DOT code declaring a left child of node n to an open file f.
 */
void write_left_link(FILE *f, node *n) {
    fprintf(f, "  n%p:left:c -> n%p:value;\n", n, n->left);
}

/*
 * Write the DOT code declaring a right child of node n to an open file f.
 */
void write_right_link(FILE *f, node *n) {
    fprintf(f, "  n%p:right:c -> n%p:value;\n", n, n->right);
}

/*********************************************************/
/*********************************************************/
/*********************************************************/
/*
 * ATTENTION! PLEASE READ THE FOLLOWING:
 * This function currently ignores the tree t.
 * It always outputs the same hard-coded tree.
 * REPLACE THE ENTIRE FUNCTION!
*/
void write_tree_aux(FILE *f, node *t) {
    if (t == NULL) {
        return;  // If the node is NULL, do nothing (base case for recursion).
    }

    // Write the current node
    write_node(f, t);

    // If there is a left child, write the link and recursively call on the left child
    if (t->left != NULL) {
        write_left_link(f, t);
        write_tree_aux(f, t->left);
    }

    // If there is a right child, write the link and recursively call on the right child
    if (t->right != NULL) {
        write_right_link(f, t);
        write_tree_aux(f, t->right);
    }
}

/*********************************************************/
/*********************************************************/
/*********************************************************/

/*
 * Open a file current-tree.dot, write the DOT code for a tree t, 
 * and convert the .dot-file to a pdf.
 */
void write_tree(node *t) {
    FILE *f;
    f = write_begin("current-tree.dot");
    write_tree_aux(f, t);
    write_end(f);
    system("dot -Tpdf current-tree.dot > current-tree.pdf");
}
