#include <stdio.h>
#include <MLV/MLV_all.h>
#include "sudoku.h"
#include "in_out.h"
#include "graphics.h"





int main(int argc, char* argv[]){
  Board B;

  if (argc != 2){
    fprintf(stderr, "Usage: %s <file>\n", argv[0]);
    return 1;
  }
  fread_board(argv[1], B);
  
  graphics_main(B);
  
  return 0;
}


