#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "array.h"
#include "sort.h"
#include "test.h"

#define MAX_VALUE 10000
#define MAX_SIZE 1000

int main(int argc, char *argv[]) {

    srand(time(NULL));

    /* tableau de travail */
    int* tab = NULL;

    /* ------------------------------TEST ENTIER ALEATOIRE--------------------------------- */

    /* Test avec un tableau de 1000 entiers aléatoire*/
    test_random(1000, MAX_VALUE);

    /* Test avec un tableau de 0 entiers aléatoire*/
    test_random(0, MAX_VALUE);

    /* Test avec un tableau de 5 entiers aléatoire*/
    test_random(5, MAX_VALUE);

    /* Test avec un tableau de 8 entiers aléatoire*/
    test_random(8, MAX_VALUE);

    /* Test avec un tableau de 10 entiers aléatoire*/
    test_random(10, MAX_VALUE);

    /* Test avec un tableau de 35628 entiers aléatoire*/
    test_random(35628, MAX_VALUE);

    /* Test avec un tableau de 124562 entiers aléatoire*/
    test_random(124562, MAX_VALUE);

    /* Test avec un tableau de 57892 entiers aléatoire*/
    test_random(57892, MAX_VALUE);

    /* Test avec un tableau de 1000 entiers aléatoire trié*/
    test_sorted(1000, MAX_VALUE);



    /* ------------------------------ TEST ENTIER TRIE ------------------------------ */


    /* Test avec un tableau de 0 entiers aléatoire trié*/
    test_sorted(0, MAX_VALUE);

    /* Test avec un tableau de 3 entiers aléatoire trié*/
    test_sorted(3, MAX_VALUE);

    /* Test avec un tableau de 6 entiers aléatoire trié*/
    test_sorted(6, MAX_VALUE);

    /* Test avec un tableau de 7 entiers aléatoire trié*/
    test_sorted(7, MAX_VALUE);

    /* Test avec un tableau de 7884 entiers aléatoire trié*/
    test_sorted(7884, MAX_VALUE);

    /* Test avec un tableau de 15698 entiers aléatoire trié*/
    test_sorted(15698, MAX_VALUE);

    /* Test avec un tableau de 75896 entiers aléatoire trié*/
    test_sorted(75896, MAX_VALUE);

    /* Test avec un tableau de 121263 entiers aléatoire trié*/
    test_sorted(121263, MAX_VALUE);

    /* ------------------ TEST ENTIER PEU DE CLES DISTINCTES ------------------------- */

    test_random(1000, 5);
    test_random(0, 5);
    test_random(5, 2);
    test_random(15, 4);
    test_random(7554, 10);
    test_random(11282, 5);


    /* ------------------ TEST ENTIER PRESQUE TRIE ------------------------- */

    test_almost_sorted(1000, MAX_VALUE, 200);

    test_almost_sorted(0, MAX_VALUE, 0);

    test_almost_sorted(5, MAX_VALUE, 2);

    test_almost_sorted(8, MAX_VALUE, 4);

    test_almost_sorted(1226, MAX_VALUE, 200);

    test_almost_sorted(1678, 6, 200); /* Peu de clé distinctes */

    test_almost_sorted(2000, 15, 200); /* Peu de clé distinctes */

    test_almost_sorted(16059, MAX_VALUE, 900);

    test_almost_sorted(28342, MAX_VALUE, 1000);


    /* ------------------ TEST ENTIER PRESQUE TRIE ------------------------- */

    test_inverted(1000, MAX_VALUE);

    test_inverted(0, MAX_VALUE);

    test_inverted(7, MAX_VALUE);

    test_inverted(12, MAX_VALUE);

    test_inverted(1678, MAX_VALUE);

    test_inverted(7456, MAX_VALUE);

    test_inverted(16459, MAX_VALUE);







    


    
    /* libération du tableau */
    free(tab);
    tab = NULL;

    return EXIT_SUCCESS;
}
