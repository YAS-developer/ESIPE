package com.example.tp3.flags

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

object TangoFlag : ICSFlag("tango") {
    override val message = "Ne me gênez pas : je fais du chalutage jumelé."

    @Composable
    override fun Flag(modifier: Modifier) {
        Row (modifier) {
            Box(Modifier.fillMaxSize().weight(1f).background(Color.Red)) {

            }
            Box(Modifier.fillMaxSize().weight(1f).background(Color.White)) {

            }
            Box(Modifier.fillMaxSize().weight(1f).background(Color.Blue)) {

            }
        }
    }
}