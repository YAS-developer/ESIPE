package fr.uge.info2.graphs;

public class Main {
  public static void main(String[] args) {
    
  }
}
