package fr.uge.info2.graphs;

import java.util.*;
import java.util.function.Consumer;

public class AdjGraph implements Graph{
  
  private final ArrayList<LinkedList<Edge>> adj;
  
  public AdjGraph(int n) {
    if(n < 0) {
      throw new IllegalArgumentException();
    }
    adj = new ArrayList<>();
    
    for(var i = 0; i < n; i++) {
      adj.add(new LinkedList<>());
    }
  }

  @Override
  public int numberOfEdges() {
    var count = 0;
    for(var noeuds : adj) {
      count += noeuds.size();
    }
    return count;
  }

  @Override
  public int numberOfVertices() {
    return adj.size();
  }

  @Override
  public void addEdge(int i, int j, int value) {
    if(value == 0) {
      throw new IllegalArgumentException("The value for adding edge can't be null = 0");
    }
    Objects.checkIndex(i, adj.size());
    Objects.checkIndex(j, adj.size());
    var list = adj.get(i);
    for(var edge : list) {
      if(edge.getEnd() == j) {
        throw new IllegalArgumentException();
      }
    }
    list.add(new Edge(i,j,value));
  }

  @Override
  public boolean isEdge(int i, int j) {
    var list = adj.get(i);
    for(var edge : list){
      if(edge.getEnd() == j){
        return true;
      }
    }
    return false;
  }

  @Override
  public int getWeight(int i, int j) {
    var list = adj.get(i);
    for(var edge : list){
      if(edge.getEnd() == j){
        return edge.getValue();
      }
    }
    return 0;
  }

  @Override
  public Iterator<Edge> edgeIterator(int i) {
    Objects.checkIndex(i, adj.size());
    var list = adj.get(i);
    return new Iterator<>() {
      private int index = 0;
      @Override
      public boolean hasNext() {
        return index < list.size();
      }

      @Override
      public Edge next() {
        if(!hasNext()) {throw new NoSuchElementException();}
        var edge = list.get(index);
        index++;
        return edge;
      }
    };
        
  }

  @Override
  public void forEachEdge(int i, Consumer<Edge> consumer) {
    Objects.requireNonNull(consumer);
    var list = adj.get(i);
    for(var edge : list){
      consumer.accept(edge);
    }
  }
}
