package fr.uge.info2.graphs;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.function.Consumer;

public class MatGraph implements Graph{
  
  private final int[][] mat;
  private final int n;
  
  public MatGraph(int nbVerices){
    this.n = nbVerices;
    this.mat = new int[nbVerices][nbVerices];
  }

  @Override
  public int numberOfEdges() {
    var nb =  0;
    for(var i = 0; i < n; i++) {
      for(var j = 0; j < n; j++) {
        if(mat[i][j] != 0) {
          nb++;
        }
      }
    }
    return nb;
  }

  @Override
  public int numberOfVertices() {
    return n;
  }

  @Override
  public void addEdge(int i, int j, int value) {
//    Objects.checkIndex(i, n);
//    Objects.checkIndex(j, n);
    if(value == 0) {
      throw new IllegalArgumentException("The value for adding edge can't be null = 0");
    }
    if(mat[i][j] != 0) {
      throw new IllegalArgumentException();
    }
    mat[i][j] = value;
  }

  @Override
  public boolean isEdge(int i, int j) {
    return mat[i][j] != 0;
  }

  @Override
  public int getWeight(int i, int j) {
    return mat[i][j];
  }

  @Override
  public Iterator<Edge> edgeIterator(int i) {
    
 
    return new Iterator<Edge>() {
      private int index = findNext(0);
      
      private int findNext(int pos) {
        while(pos < mat.length) {
          if(mat[i][pos] != 0) {
            return pos;
          }
          pos++;
        }
        return pos;
      }
      
      @Override
      public boolean hasNext() {
        return index < mat.length;
      }
      
      @Override
      public Edge next() {
        if(!hasNext()) {
          throw new NoSuchElementException();
        }
        var edge = new Edge(i, index, mat[i][index]);
        index = findNext(index + 1);
        return edge;
      }
    };
  }

  @Override
  public void forEachEdge(int i, Consumer<Edge> consumer) {
    Objects.requireNonNull(consumer);
    for(var j = 0; j < mat.length; j++) {
      if(mat[i][j] != 0) {
        consumer.accept(new Edge(i, j, mat[i][j]));
      }
    }
  }

}
