package fr.uge.info2.graphs;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.LongAdder;

public class Graphs {

  private static void recDFS(Graph g, int s, boolean[] visited, List<Integer> list){
    visited[s] = true;
    list.add(s);
    g.forEachEdge(s, edge -> {
      var t = edge.getEnd();
      if(!visited[t]){
        recDFS(g, t, visited, list);
      }
    });
  }

  public static List<Integer> DFS(Graph g, int s0){
    var list = new ArrayList<Integer>();
    var visited = new boolean[g.numberOfVertices()];
    recDFS(g, s0, visited, list);
//    for(var i = s0; i < g.numberOfVertices(); i++){
//      if(!visited[i]){
//        recDFS(g, i, visited, list);
//      }
//    }
    return list;
  }

  public static List<Integer> BFS(Graph g, int s0){
    var list = new ArrayList<Integer>();
    var visited = new boolean[g.numberOfVertices()];
//    var previous = new Integer[g.numberOfVertices()];
    var queue = new ArrayDeque<Integer>();
    visited[s0] = true;
    queue.add(s0);
    while (!queue.isEmpty()){
      var s = queue.poll();
      list.add(s);
      g.forEachEdge(s, edge -> {
        var t = edge.getEnd();
        if(!visited[t]){
          visited[t] = true;
//          previous[t] = s;
          queue.add(t);
        }
      });
    }
    return list;
  }

  private static void recTimedDFS(Graph g, int s, int[][] tab, boolean[] visited, LongAdder time){
    visited[s] = true;
    time.increment();
    tab[0][s] = time.intValue();

    g.forEachEdge(s, edge -> {
      var t = edge.getEnd();
      if(!visited[t]){
        recTimedDFS(g, t, tab, visited, time);
      }
    });
    time.increment();
    tab[1][s] = time.intValue();

  }

  public static int[][] timedDepthFirstSearch(Graph g, int s0){
    Objects.requireNonNull(g);
    var nbVertices = g.numberOfVertices();
    var tab = new int[2][nbVertices];
    var visited = new boolean[nbVertices];
    var time = new LongAdder();
    System.out.println(time.intValue());
    recTimedDFS(g, s0, tab, visited, time);

    return tab;
  }

  public static boolean isNonOriented(Graph g){
    Objects.requireNonNull(g);
    for(var i = 0; i < g.numberOfVertices(); i++){
      var iterator = g.edgeIterator(i);
      while (iterator.hasNext()){
        var edge = iterator.next();
        var start = edge.getStart();
        var end = edge.getEnd();
        var value = edge.getValue();
        if(!(g.isEdge(end, start) &&  value == g.getWeight(end, start))){
          return false;
        }
      }
    }
    return true;
  }

  public static boolean isConnected(Graph g){
    Objects.requireNonNull(g);
    if(!isNonOriented(g)){
      throw new IllegalArgumentException("Graph must be oriented");
    }
    if(g.numberOfVertices() == 0){
      return true;
    }

    var visited = new boolean[g.numberOfVertices()];
    recDFS(g, 0, visited, new ArrayList<>());

    for(var v : visited){
      if(!v){
        return false;
      }
    }
    
    return true;
  }
}
