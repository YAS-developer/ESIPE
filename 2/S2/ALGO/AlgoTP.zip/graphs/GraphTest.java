package fr.uge.info2.graphs;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.*;
import java.util.function.IntFunction;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;


public class GraphTest{


  @Nested
  public class Q1{
    private Graph createGraph(int size) {
      return new MatGraph(size);
    }

    @Test
    public void testCreateGraph() {
      Graph g = createGraph(5);
      assertEquals(5, g.numberOfVertices());
      assertEquals(0, g.numberOfEdges());
    }
    
    @Test
    public void testNumberOfEdges() {
        Graph g = createGraph(5);
        assertEquals(0, g.numberOfEdges());
        g.addEdge(0, 1, 10);
        assertEquals(1, g.numberOfEdges());
        g.addEdge(1, 2, -5);
        g.addEdge(2, 3, 3);
        assertEquals(3, g.numberOfEdges());
    }

    @Test
    public void testAddAndCheckEdges() {
      Graph g = createGraph(4);
      g.addEdge(0, 1, 3);
      g.addEdge(1, 2, -2);
      g.addEdge(2, 3, 5);

      assertTrue(g.isEdge(0, 1));
      assertEquals(3, g.getWeight(0, 1));
      assertEquals(-2, g.getWeight(1, 2));
      assertThrows(IndexOutOfBoundsException.class, () -> g.getWeight(4, 0));
    }

    @Test
    public void testAddEdgeErrors() {
      Graph g = createGraph(3);
      assertThrows(IndexOutOfBoundsException.class, () -> g.addEdge(0, 3, 1));
      assertThrows(IllegalArgumentException.class, () -> g.addEdge(0, 1, 0));
      g.addEdge(1, 2, 7);
      assertThrows(IllegalArgumentException.class, () -> g.addEdge(1, 2, 9));
    }

    @Test
    public void testEdgeIterator() {
      Graph g = createGraph(3);
      g.addEdge(0, 1, 5);
      g.addEdge(0, 2, 8);

      Iterator<Edge> it = g.edgeIterator(0);
      Set<Edge> edges = new HashSet<>();
      while (it.hasNext()) {
        edges.add(it.next());
      }
      assertEquals(Set.of(new Edge(0, 1, 5), new Edge(0, 2, 8)), edges);
    }

    @Test
    public void testForEachEdge() {
      Graph g = createGraph(2);
      g.addEdge(0, 1, 10);
      List<Edge> collected = new ArrayList<>();
      g.forEachEdge(0, collected::add);
      assertEquals(List.of(new Edge(0, 1, 10)), collected);
    }

//    @Test
//    public void testToGraphviz() {
//      Graph g = createGraph(2);
//      g.addEdge(0, 1, 2);
//      String dot = g.toGraphviz();
//      assertTrue(dot.contains("digraph G"));
//      assertTrue(dot.contains("0 -> 1 [ label=\"2\" ]"));
//    }
  }
  
  @Nested
  public class Q2{
    private Graph createGraph(int size) {
      return new AdjGraph(size);
    }

    @Test
    public void testCreateGraph() {
      Graph g = createGraph(5);
      assertEquals(5, g.numberOfVertices());
      assertEquals(0, g.numberOfEdges());
    }
    
    @Test
    public void testNumberOfEdges() {
        Graph g = createGraph(5);
        assertEquals(0, g.numberOfEdges());
        g.addEdge(0, 1, 10);
        assertEquals(1, g.numberOfEdges());
        g.addEdge(1, 2, -5);
        g.addEdge(2, 3, 3);
        assertEquals(3, g.numberOfEdges());
    }

    @Test
    public void testAddAndCheckEdges() {
      Graph g = createGraph(4);
      g.addEdge(0, 1, 3);
      g.addEdge(1, 2, -2);
      g.addEdge(2, 3, 5);

      assertTrue(g.isEdge(0, 1));
      assertEquals(3, g.getWeight(0, 1));
      assertEquals(-2, g.getWeight(1, 2));
      assertThrows(IndexOutOfBoundsException.class, () -> g.getWeight(4, 0));
    }

    @Test
    public void testAddEdgeErrors() {
      Graph g = createGraph(3);
      assertThrows(IndexOutOfBoundsException.class, () -> g.addEdge(0, 3, 1));
      assertThrows(IllegalArgumentException.class, () -> g.addEdge(0, 1, 0));
      g.addEdge(1, 2, 7);
      assertThrows(IllegalArgumentException.class, () -> g.addEdge(1, 2, 9));
    }

    @Test
    public void testEdgeIterator() {
      Graph g = createGraph(3);
      g.addEdge(0, 1, 5);
      g.addEdge(0, 2, 8);

      Iterator<Edge> it = g.edgeIterator(0);
      Set<Edge> edges = new HashSet<>();
      while (it.hasNext()) {
        edges.add(it.next());
      }
      assertEquals(Set.of(new Edge(0, 1, 5), new Edge(0, 2, 8)), edges);
    }

    @Test
    public void testForEachEdge() {
      Graph g = createGraph(2);
      g.addEdge(0, 1, 10);
      List<Edge> collected = new ArrayList<>();
      g.forEachEdge(0, collected::add);
      assertEquals(List.of(new Edge(0, 1, 10)), collected);
    }

//    @Test
//    public void testToGraphviz() {
//      Graph g = createGraph(2);
//      g.addEdge(0, 1, 2);
//      String dot = g.toGraphviz();
//      assertTrue(dot.contains("digraph G"));
//      assertTrue(dot.contains("0 -> 1 [ label=\"2\" ]"));
//    }
  }

  @Nested
  public class Q3{
    static Stream<IntFunction<Graph>> graphProviders() {
      return Stream.of(MatGraph::new, AdjGraph::new);
    }

    private Graph buildSmallGraph(IntFunction<Graph> factory) {
      Graph g = factory.apply(5);
      g.addEdge(0, 1, 1);
      g.addEdge(0, 2, 1);
      g.addEdge(1, 3, 1);
      g.addEdge(2, 3, 1);
      g.addEdge(3, 4, 1);
      return g;
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testDFSBasic(IntFunction<Graph> factory) {
      Graph g = buildSmallGraph(factory);
      List<Integer> dfs = Graphs.DFS(g, 0);
      dfs.sort(Integer::compareTo);
      assertEquals(List.of(0, 1, 2, 3, 4), dfs);
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testBFSBasic(IntFunction<Graph> factory) {
      Graph g = buildSmallGraph(factory);
      List<Integer> bfs = Graphs.BFS(g, 0);
      assertEquals(List.of(0, 1, 2, 3, 4), bfs);
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testDFSDisconnected(IntFunction<Graph> factory) {
      Graph g = factory.apply(6);
      g.addEdge(0, 1, 1);
      g.addEdge(1, 2, 1);
      g.addEdge(3, 4, 1); // non connecté
      List<Integer> dfs = Graphs.DFS(g, 0);
      dfs.sort(Integer::compareTo);
      assertEquals(List.of(0, 1, 2), dfs);
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testBFSDisconnected(IntFunction<Graph> factory) {
      Graph g = factory.apply(6);
      g.addEdge(0, 1, 1);
      g.addEdge(1, 2, 1);
      g.addEdge(3, 4, 1); // non connecté
      List<Integer> bfs = Graphs.BFS(g, 0);
      assertEquals(List.of(0, 1, 2), bfs);
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testDFSInvalidStart(IntFunction<Graph> factory) {
      Graph g = factory.apply(3);
      assertThrows(IndexOutOfBoundsException.class, () -> Graphs.DFS(g, 5));
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testBFSInvalidStart(IntFunction<Graph> factory) {
      Graph g = factory.apply(3);
      assertThrows(IndexOutOfBoundsException.class, () -> Graphs.BFS(g, -1));
    }
  }
  @Nested
  public class Q2_TimedDFS_Test {

    static Stream<IntFunction<Graph>> graphProviders() {
      return Stream.of(MatGraph::new, AdjGraph::new);
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testTimedDFS(IntFunction<Graph> factory) {
      Graph g = factory.apply(4);
      g.addEdge(0, 1, 1);
      g.addEdge(1, 2, 1);
      g.addEdge(2, 3, 1);

      int[][] timestamps = Graphs.timedDepthFirstSearch(g, 0);
      assertEquals(2, timestamps.length);
      assertEquals(g.numberOfVertices(), timestamps[0].length);
      assertEquals(g.numberOfVertices(), timestamps[1].length);

      for (int i = 0; i < g.numberOfVertices(); i++) {
        assertTrue(timestamps[0][i] > 0, "start time should be positive for " + i);
        assertTrue(timestamps[1][i] > 0, "end time should be positive for " + i);
        assertTrue(timestamps[0][i] < timestamps[1][i], "start < end for " + i);
      }
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testTimedDFSDisconnected(IntFunction<Graph> factory) {
      Graph g = factory.apply(5);
      g.addEdge(0, 1, 1);
      g.addEdge(2, 3, 1);

      int[][] timestamps = Graphs.timedDepthFirstSearch(g, 0);

      for (int i = 0; i < g.numberOfVertices(); i++) {
        if (i == 0 || i == 1) {
          assertTrue(timestamps[0][i] > 0);
          assertTrue(timestamps[1][i] > 0);
        } else {
          assertEquals(0, timestamps[0][i]);
          assertEquals(0, timestamps[1][i]);
        }
      }
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testTimedDFSInvalidStart(IntFunction<Graph> factory) {
      Graph g = factory.apply(3);
      assertThrows(IndexOutOfBoundsException.class, () -> Graphs.timedDepthFirstSearch(g, -1));
      assertThrows(IndexOutOfBoundsException.class, () -> Graphs.timedDepthFirstSearch(g, 3));
    }
  }
  @Nested
  public class Q3_IsNonOriented_Test {

    static Stream<IntFunction<Graph>> graphProviders() {
      return Stream.of(MatGraph::new, AdjGraph::new);
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testIsNonOrientedSymmetric(IntFunction<Graph> factory) {
      Graph g = factory.apply(3);
      g.addEdge(0, 1, 1);
      g.addEdge(1, 0, 1);
      g.addEdge(1, 2, 1);
      g.addEdge(2, 1, 1);
      g.addEdge(0, 2, 1);
      g.addEdge(2, 0, 1);

      assertTrue(Graphs.isNonOriented(g));
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testIsNonOrientedAsymmetric(IntFunction<Graph> factory) {
      Graph g = factory.apply(3);
      g.addEdge(0, 1, 1);
      g.addEdge(1, 2, 1);
      g.addEdge(2, 0, 1); // manque les arcs inverses

      assertFalse(Graphs.isNonOriented(g));
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testIsNonOrientedDifferentWeights(IntFunction<Graph> factory) {
      Graph g = factory.apply(2);
      g.addEdge(0, 1, 5);
      g.addEdge(1, 0, 3); // symétrique mais poids ≠

      assertFalse(Graphs.isNonOriented(g));
    }

    @ParameterizedTest
    @MethodSource("graphProviders")
    public void testIsNonOrientedEmptyGraph(IntFunction<Graph> factory) {
      Graph g = factory.apply(5); // aucun arc
      assertTrue(Graphs.isNonOriented(g)); // vide = non orienté
    }
  }

  @Nested
  public class Q4_IsConnected_Test {
    private void createUndirectedEdge(Graph g, int i, int j, int w) {
      g.addEdge(i, j, w);
      g.addEdge(j, i, w);
    }

    @Test
    public void testConnectedUndirectedGraph() {
      Graph g = new MatGraph(4);
      createUndirectedEdge(g, 0, 1, 1);
      createUndirectedEdge(g, 1, 2, 1);
      createUndirectedEdge(g, 2, 3, 1);

      assertTrue(Graphs.isConnected(g));
    }

    @Test
    public void testDisconnectedUndirectedGraph() {
      Graph g = new MatGraph(4);
      createUndirectedEdge(g, 0, 1, 1);
      createUndirectedEdge(g, 2, 3, 1);

      assertFalse(Graphs.isConnected(g));
    }

    @Test
    public void testGraphWithMissingReverseEdge() {
      Graph g = new MatGraph(3);
      g.addEdge(0, 1, 1); // Pas de retour 1 → 0 → doit lever une exception

      assertThrows(IllegalArgumentException.class, () -> Graphs.isConnected(g));
    }

    @Test
    public void testTrivialGraph() {
      Graph g = new MatGraph(1);
      assertTrue(Graphs.isConnected(g));
    }

    @Test
    public void testEmptyGraph() {
      Graph g = new MatGraph(0);
      assertTrue(Graphs.isConnected(g)); // Convention : un graphe vide est connexe
    }
  }


}
