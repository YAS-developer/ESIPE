package fr.uge.info2.algoadv;

import java.util.ArrayList;

public class GraphAlgo {
	
	public static boolean hasSink(Graph g) {
		// TODO: returns whether the given graph contains a sink, 
		// i.e., vertex without outgoing edge to other vertices (but can have a loop).
		// Complexity should be O(V + E)
		return false;
	}
	
	public static boolean hasTriangle(Graph g) {
		// TODO: returns whether the graph has any oriented triangle in it.
		// The three vertices of the triangle must all be different
		// Complexity should be O(V^3)
		return false;
	}
	
	public static ArrayList<Integer> dfs(Graph g, int v) {
		// TODO: return the list of vertices visited by DFS starting from v. 
		// Neighbors should be visited in the order given by edge iterator.
		// Complexity should be O(V + E)
		return new ArrayList<Integer>();
	}
	
	public static boolean hasCycle(Graph g) {
		// TODO: return whether the graph has a cycle (loops are also counted as cycles)
		// Complexity should be O(V + E)
		return false;
	}
	
	public static boolean isCycle(Graph g, ArrayList<Integer> vertexList) {
		// TODO: return whether the given list of vertices in the order is an oriented cycle of the given graph
		// If the list is empty, the function should return false.
		return false;
	}
	
	public static ArrayList<Integer> findCycle(Graph g) {
		// TODO: return any oriented cycle in the given graph. If none exists, returns an empty list
		return new ArrayList<Integer>();
	}
}
