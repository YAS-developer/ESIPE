/**
 *  Author: Wenjie Fang
 *  For TP of Advanced Algorithms, ESIPE INFO 2, UGE
 *  DO NOT MODIFY!
 */
package fr.uge.info2.algoadv;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Objects;
import java.util.function.Consumer;

/**
 *  Implementation of a graph using adjacency lists of Edge
 */
public class AdjGraph implements Graph {
	
	// adjacency lists
	private final ArrayList<LinkedList<Edge>> adj;
	// number of vertices
	private final int n;
	// number of edges
	private int edgeCount;
	
	public AdjGraph(int n) {
		if(n <= 0) {
			throw new IllegalArgumentException("Size should be non-negative.");
		}
		this.n = n;
		this.adj = new ArrayList<LinkedList<Edge>>(this.n);
		for (int i = 0; i < this.n; i++) {
			this.adj.add(new LinkedList<Edge>());
		}
		this.edgeCount = 0;
	}

	@Override
	public int numberOfEdges() {
		// returns the number of edges, which may change and is kept in a variable
		return edgeCount;
	}

	@Override
	public int numberOfVertices() {
		// returns the number of vertices, which does not change
		return n;
	}

	@Override
	public void addEdge(int i, int j, int value) {
		// adds an edge while first checking existence
		// check indices
		Objects.checkIndex(i, n);
		Objects.checkIndex(j, n);
		// check if value is 0
		if (value == 0) {
			throw new IllegalArgumentException("Edge weight cannot be zero.");
		}
		// check if the edge already exists
		if (isEdge(i, j)) {
			throw new IllegalArgumentException("Edge already exists");
		}
		// now add the edge
		adj.get(i).add(new Edge(i, j, value));
		edgeCount++;
	}

	@Override
	public boolean isEdge(int i, int j) {
		// check whether the edge from i to j exists
		Objects.checkIndex(i, n);
		Objects.checkIndex(j, n);
		return adj.get(i).stream().filter(e -> e.getEnd() == j).findAny().isPresent();
	}

	@Override
	public int getWeight(int i, int j) {
		// get the weight, returns 0 if the edge does not exists
		Objects.checkIndex(i, n);
		Objects.checkIndex(j, n);
		var edge = adj.get(i).stream().filter(e -> e.getEnd() == j).findAny();
		return edge.isPresent() ? edge.get().getValue() : 0;
	}

	@Override
	public Iterator<Edge> edgeIterator(int i) {
		// returns an iterator of edges starting with i
		Objects.checkIndex(i, n);
		return adj.get(i).iterator();
	}

	@Override
	public void forEachEdge(int i, Consumer<Edge> consumer) {
		// perform an operation on each edge starting with i
		Objects.checkIndex(i, n);
		edgeIterator(i).forEachRemaining(consumer);
	}

	@Override
	public String toGraphviz() {
		// convert to dot format
		var sb = new StringBuilder();
		sb.append("digraph G {\n");
		for (int i = 0; i < n; i++) {
			sb.append("  " + i + ";\n");
			forEachEdge(i, e -> sb.append("  " + e.toStringGraphviz()));
		}
		sb.append("}");
		return sb.toString();
	}

	@Override
	public boolean removeEdge(int i, int j) {
		// removes an edge, does nothing if it does not exist
		Objects.checkIndex(i, n);
		Objects.checkIndex(j, n);
		if (adj.get(i).removeIf(e -> e.getEnd() == j)) {
			edgeCount--;
			return true;
		}
		return false;
	}

}
