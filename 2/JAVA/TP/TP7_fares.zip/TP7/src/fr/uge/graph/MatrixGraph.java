package fr.uge.graph;

import java.util.Objects;
import java.util.Optional;
import java.util.function.BiFunction;

final class MatrixGraph<T> implements Graph<T>{
  
  private final T[] tab;
  private final int nodeCount;
  
  
  @SuppressWarnings("unchecked")
  public MatrixGraph(int nodeCount) {
    if(nodeCount < 0) {
      throw new IllegalArgumentException();
    }
    this.tab = (T[]) new Object[nodeCount * nodeCount];
    this.nodeCount = nodeCount;
  }
  
  @Override
  public int nodeCount() {
    return nodeCount;
  }
  
  int index(int src, int dst) {
    return src * nodeCount + dst;
  }

  @Override
  public void addEdge(int src, int dst, T weight) {
    Objects.checkIndex(src, nodeCount);
    Objects.checkIndex(dst, nodeCount);
    Objects.requireNonNull(weight);
    tab[index(src, dst)] = weight;
  }

  @Override
  public Optional<T> getWeight(int src, int dst) {
    Objects.checkIndex(src, nodeCount);
    Objects.checkIndex(dst, nodeCount);
    return Optional.ofNullable(tab[index(src, dst)]);
  }

  @Override
  public <U extends T> void mergeAll(Graph<U> graph, BiFunction<? super T, ? super U, ? extends T> merger) {
    Objects.requireNonNull(graph, "The graph must not be null");
    Objects.requireNonNull(merger, "The merger function must not be null");

    if (graph.nodeCount() != this.nodeCount) {
      throw new IllegalArgumentException("Graphs must have the same number of nodes");
    }
    
    for(var i = 0; i < nodeCount; i++) {
      for(var j = 0; j < nodeCount; j++) {
        var weightOpt = graph.getWeight(i, j);
        if(weightOpt.isEmpty()) {
          continue;
        }
        
        var newWeight = weightOpt.get();   
        var currWeightOpt = getWeight(i, j);
        T tmp = newWeight;
        if(currWeightOpt.isPresent()) {
          tmp = merger.apply(currWeightOpt.get(), newWeight);
        }
        this.addEdge(i, j, tmp);
      }
    }
  }


}
